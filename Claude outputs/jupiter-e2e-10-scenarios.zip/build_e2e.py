"""Build the 10-scenario end-to-end CSV pack from OutcomeAI's Jupiter data and a live chain run.
Usage: python3 build_e2e.py --data <sample-data/quote/jupiter-knitting> --run /tmp/chain10.json --out <dir>
"""
import argparse, csv, json, os

ap = argparse.ArgumentParser()
ap.add_argument("--data", required=True)
ap.add_argument("--run", required=True)
ap.add_argument("--out", required=True)
ap.add_argument("--as-of", default="2026-11-16")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
J = lambda n: json.load(open(os.path.join(a.data, n)))
products, lots, sail, air, led, cust, pol = (J("products.json")["products"], J("inventory-lots.json")["lots"], J("sailings.json"),
                                             J("air.json"), J("treasury-ledger.json"), J("customers.json")["customers"], J("business-policy.json"))
run = json.load(open(a.run))
usd = lambda c: "" if c is None else f"{c/100:.2f}"

def w(name, head, rows):
    with open(os.path.join(a.out, name), "w", newline="") as f:
        x = csv.writer(f); x.writerow(head); x.writerows(rows)

w("products.csv", ["sku", "family", "grade", "uom", "description", "unit_cost_usd", "units_per_40hc", "production_lead_days", "capacity_per_cycle", "production_warehouse"],
  [[p["sku"], p["family"], p["grade"], p.get("uom", "UNIT"), p["description"], usd(p["unitCostCents"]), p["unitsPer40HC"], p["productionLeadDays"], p["capacityPerCycle"], p["productionWarehouse"]] for p in products])

# City/country: sample values (not in OutcomeAI customers.json); tier from inventory lots / Signatory authority config.
LOC = {"tommy-hilfiger-europe": ("Amsterdam", "Netherlands", "TIER1"), "orion-apparel": ("New York", "United States", "TIER2"), "mercury-textiles": ("Hamburg", "Germany", "TIER1")}
w("customers.csv", ["customer_id", "name", "city", "country", "tier", "credit_limit_usd", "open_receivable_usd", "credit_headroom_usd", "role_in_scenarios"],
  [[c["id"], c["name"], *LOC[c["id"]], c["creditLimitUsd"], c["openReceivableUsd"], c["creditLimitUsd"] - c["openReceivableUsd"],
    "buyer (tommyBuyerAgent)" if c["id"] == "tommy-hilfiger-europe" else "other customer: its allocated lots can be reallocated"] for c in cust])

w("inventory_lots.csv", ["lot", "sku", "warehouse", "kind", "on_hand", "reserved", "qc_hold", "available_to_promise", "ready_date", "allocated_to", "tier", "realloc_needs"],
  [[l["lot"], l["sku"], l["warehouse"], l["kind"], l["onHand"], l["reserved"], l["qcHold"],
    (l["onHand"] - l["qcHold"]) if l["kind"] == "ALLOCATED" else max(0, l["onHand"] - l["reserved"] - l["qcHold"]),
    l["readyDate"], l.get("allocatedTo", ""), l.get("tier", ""), pol["reallocAuthority"].get(l.get("tier"), "") if l.get("tier") else ""] for l in lots])

w("logistics_routes.csv", ["mode", "carrier", "from", "to", "etd", "eta", "delivered_dap_la", "rate_usd", "rate_basis", "notes"],
  [[s["mode"], s["carrier"], sail["originPort"], sail["destinationPort"], s["etd"], s["eta"], "", s["ratePer40HcUsd"], "per 40HC",
    f"cargo cutoff = ETD - {pol['cutoffDaysBeforeEtd']}d; delivered = ETA + {pol['customsDays']}d customs + {pol['drayageDays']}d drayage"] for s in sail["sailings"]]
  + [["AIR", air["carrier"], "INMAA", "USLAX", "at port", "", f"at port + {air['transitDays'] + air['clearanceDays']}d", usd(air["centsPerUnit"]), "per unit", f"max {air['maxUnits']} units per order; Sales Officer up to 10% of qty, CEO any"]])
# fill delivered date
import datetime as dt
rows = list(csv.reader(open(os.path.join(a.out, "logistics_routes.csv"))))
for r in rows[1:]:
    if r[0] != "AIR": r[6] = (dt.date.fromisoformat(r[5]) + dt.timedelta(days=pol["customsDays"] + pol["drayageDays"])).isoformat()
w("logistics_routes.csv", rows[0], rows[1:])

w("treasury_ledger.csv", ["type", "party", "amount_usd", "due_date", "in_30_day_window"],
  [["CASH", "Jupiter bank", led["cashUsd"], a.as_of, "Y"], ["CREDIT_LINE_HEADROOM", "Jupiter bank", led["creditLineHeadroomUsd"], a.as_of, "Y"]]
  + [["RECEIVABLE", r["customer"], r["amountUsd"], r["dueDate"], "Y" if r["dueDate"] <= "2026-12-16" else "N"] for r in led["receivables"]]
  + [["PAYABLE", p["vendor"], p["amountUsd"], p["dueDate"], "Y" if p["dueDate"] <= "2026-12-16" else "N"] for p in led["payables"]])

w("business_policy.csv", ["key", "value"], [[k, json.dumps(v) if isinstance(v, (dict, list)) else v] for k, v in pol.items()])

# ---- scenarios + agent queries
def inv_q(r):  return f"Can Jupiter supply {r['qty']:,} x {r['sku']} ready to ship by {r['shipBy']}? Which lots, any shortfall, which other customers' lots could be reallocated, any better grade?"
def inv_a(r):
    s = "; ".join(f"{x['lot']} {x['kind']} {x['units']:,} ready {x['readyDate']}" for x in r["sources"]) or "no own stock"
    re_ = "; ".join(f"{x['lot']} {x['tier']} {x['units']:,} needs {x['requiredAuthority']} +{x['premiumPct']}%" for x in r["reallocatable"])
    return f"sources: {s} | shortfall {r['shortfall']:,}" + (f" | reallocatable: {re_}" if re_ else "") + (f" | better grade: {', '.join(g['sku'] for g in r['gradeAlternatives'])}" if r["gradeAlternatives"] else "")
def log_q(r):  return f"Ship {', '.join(f'''{l['lot']} ({l['units']:,}, ready {l['readyDate']}, {l['warehouse']})''' for l in r['lots'])} to DAP Los Angeles by {r['deadline']}{' - air allowed' if r['allowAir'] else ' - sea only'}. Which sailing, delivered when, freight?"
def log_a(r):  return " | ".join(f"{g['lot']} {g['mode']} {g['carrier']} ETD {g['etd']} -> {g['delivered']}{' LATE' if g['late'] else ''}" for g in r["legs"]) + f" | freight ${r['freightCents']/100:,.0f} | on time: {r['meetsDeadline']}"
def tre_q(r):  return (f"{r['qty']:,} x {r['sku']}, freight ${r['freightCents']/100:,.0f}, reallocated T2 {r['reallocUnits']['TIER2']:,} / T1 {r['reallocUnits']['TIER1']:,}, "
                       f"{r['termsDays']}-day terms, {r['advancePct']}% advance: landed cost, price at each margin, liquidity, Tommy's credit?")
def tre_a(r):  return (f"landed ${usd(r['landedCents'])} | 15% ${usd(r['pricesAtMargin']['0.15'])}, 12% ${usd(r['pricesAtMargin']['0.12'])}, 8% ${usd(r['pricesAtMargin']['0.08'])} | realloc premium ${usd(r['reallocPremiumCents'])} | "
                       f"net30 ${r['liquidity']['net30Usd']:,} {r['liquidity']['status']} | credit headroom ${r['credit']['headroomUsd']:,} ok={r['credit']['ok']}")
def syn_q(r):
    last = r["history"][-1]
    who = "CEO brief" if r["mode"] == "ceo-brief" else f"Round {r['round']}"
    return f"{who} at {r['authority']['level']} (floor ${usd(r['authority']['floorCents'])}): Tommy's last offer ${usd(last['priceCents'])} for {r['inquiry']['qty']:,} x {r['inquiry']['sku']} by {r['inquiry']['deadline']}. Accept, counter or escalate?"
def syn_a(r):
    p = r.get("proposal") or {}
    return f"{p.get('decision')} ${usd((p.get('counter') or {}).get('priceCents'))} | to Tommy: {r.get('messageToBuyer', '')}"
Q = {"agents/inventory": (inv_q, inv_a), "agents/logistics": (log_q, log_a), "agents/treasury": (tre_q, tre_a), "seller/synthesize": (syn_q, syn_a)}

def ok(path, req, res):
    if path == "agents/inventory": return "YES" if res["shortfall"] == 0 else "NO"
    if path == "agents/logistics": return "YES" if res["meetsDeadline"] else "NO"
    if path == "agents/treasury": return "YES" if res["liquidity"]["status"] == "SURPLUS" and res["credit"]["ok"] else "NO"
    return (res.get("proposal") or {}).get("decision", "")

qrows, srows = [], []
for rec in run:
    s, rq = rec["scenario"], rec["rfq"]
    for i, c in enumerate(rec["calls"], 1):
        qf, af = Q[c["path"]]
        req = {k: v for k, v in c["request"].items() if k != "requestId"}
        res = c["response"]
        brief = json.dumps(req) if c["path"] != "seller/synthesize" else json.dumps({k: req[k] for k in ("mode", "inquiry", "round", "history", "authority")})
        qrows.append([s["id"], i, c["alias"], f"POST /v1/tenants/jupiter-knitting/{c['path']}", qf(c["request"]), brief, af(res), ok(c["path"], c["request"], res)])
    calls = rec["calls"]
    first = lambda p: next((c for c in calls if c["path"] == p), None)
    inv, tre = first("agents/inventory"), first("agents/treasury")
    logs = [c for c in calls if c["path"] == "agents/logistics"]
    r = rec.get("result") or {}
    srows.append([s["id"], s["title"], rq["customer"], "Amsterdam, Netherlands", rq["agent"], rq["place"] + " (USLAX)", rq["sku"], rq["grade"], rq["qty"], usd(rq["targetCents"]), rq["deadline"],
                  rq["termsDays"], rq["advancePct"], usd(rq["buyerBudgetCents"]),
                  (f"YES" if inv["response"]["shortfall"] == 0 else f"NO (short {inv['response']['shortfall']:,})") if inv else "",
                  (f"YES" if logs[0]["response"]["meetsDeadline"] else f"NO ({logs[0]['response']['lateUnits']:,} late)") if logs else "",
                  "" if not tre else ok("agents/treasury", None, tre["response"]),
                  s["expect"], "FAILED: " + rec["error"] if rec.get("error") else r["decision"], r.get("sku", ""), "" if r.get("decision") == "DECLINE" else usd(r.get("priceCents")),
                  "" if r.get("totalUsd") is None or r.get("decision") == "DECLINE" else f"{r['totalUsd']:.2f}",
                  "; ".join(f"{x['units']:,} by {x['deliveredBy']}" for x in r.get("shipments", [])), r.get("decidedBy", ""), r.get("rounds", ""), ",".join(r.get("reasons", []))])

w("scenarios_e2e.csv", ["scenario", "title", "customer", "customer_location", "buyer_agent", "deliver_to", "sku_requested", "grade", "qty", "target_price_usd", "deliver_by",
                        "terms_days", "advance_pct", "tommy_private_max_usd", "inventory_possible_first_ask", "logistics_possible_first_ask", "treasury_ok",
                        "expected_path", "outcome", "sku_delivered", "agreed_price_usd", "order_value_usd", "deliveries", "decided_by", "rounds", "escalation_reasons"], srows)
w("agent_queries_e2e.csv", ["scenario", "seq", "agent", "endpoint", "query_plain_english", "request_json", "answer_summary", "possible"], qrows)
print(f"wrote {len(srows)} scenarios, {len(qrows)} agent calls to {a.out}")
