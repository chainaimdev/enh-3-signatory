// 10 end-to-end quote scenarios: Tommy RFQ -> Inventory -> Logistics -> plan -> Treasury -> seller -> rounds/escalation.
// Runs Signatory's real runQuote against a live quote-agents (OutcomeAI) and writes every agent call to JSON.
// Usage: node services/chain-10.mjs --outcome-url http://127.0.0.1:8786 --out /tmp/chain10.json [--only S03]
import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { parseArgs } from "node:util";
import { ROOT } from "../scripts/lib/common.mjs";
import { createOutcomeClient } from "./shared/outcome-client.mjs";
import { createRuleBuyer } from "./runner/quote-buyer.mjs";
import { loadQuotePolicy, runQuote } from "./runner/quote-flow.mjs";

const { values: f } = parseArgs({ options: {
  "outcome-url": { type: "string", default: "http://127.0.0.1:8786" },
  out: { type: "string", default: "/tmp/chain10.json" },
  only: { type: "string" },
  decide: { type: "string", default: "approve" }, // what officers answer when escalated: approve | reject
} });
const policy = loadQuotePolicy(resolve(ROOT, "config", "quote-authority.json"));
const base = JSON.parse(readFileSync(resolve(ROOT, "data", "quote", "inquiries.json"), "utf8")).inquiries[0];
const DESC = Object.fromEntries(JSON.parse(readFileSync(process.env.PRODUCTS_JSON, "utf8")).products.map((p) => [p.sku, p.description]));

const S = (id, title, expect, r) => ({ id, title, expect, ...r });
export const SCENARIOS = [
  S("S01", "Everything possible, Tommy accepts in round 1", "INV ok · LOG ok (sea) · TRE ok · ACCEPT R1 by agent",
    { sku: "FAB-JERSEY-140-A", qty: 30000, cents: 300, deadline: "2027-01-08", terms: 30, advance: 0, budget: 320 }),
  S("S02", "Counter, then Tommy accepts in round 2", "INV ok (free+WIP) · LOG ok (std+express) · TRE ok · ACCEPT R2 by agent",
    { sku: "GAR-TSHIRT-CREW-A", qty: 20000, cents: 270, deadline: "2027-01-08", terms: 30, advance: 0, budget: 302 }),
  S("S03", "Big order on 60-day credit: stock short, new production fills it; treasury flags DEFICIT and credit over limit", "INV ok only with PRODUCTION · LOG ok · TRE NOT ok (deficit, credit) · flow still quotes",
    { sku: "FAB-PC-160-A", qty: 60000, cents: 300, deadline: "2027-01-20", terms: 60, advance: 0, budget: 330 }),
  S("S04", "Grade B (stock + new production) cannot reach LA by 28 Dec: Jupiter offers Grade A instead", "INV ok (needs production) · LOG NOT ok for grade B · grade A re-consult ok · TRE ok",
    { sku: "FAB-JERSEY-140-B", qty: 30000, cents: 280, deadline: "2026-12-28", terms: 30, advance: 0, budget: 310, grade: "B" }),
  S("S05", "Second batch late: split shipment (>= 70% on time)", "INV ok · LOG NOT ok for WIP lot · split 75/25 · TRE ok (30% advance)",
    { sku: "GAR-SAREE-COT-A", qty: 8000, cents: 780, deadline: "2026-12-28", terms: 30, advance: 30, budget: 905 }),
  S("S06", "Only stock is another customer's (Tier 2): Sales Officer must approve", "INV NOT ok (free) · TIER2 reallocation · escalate Sales Officer",
    { sku: "FAB-LIN-150-A", qty: 5000, cents: 640, deadline: "2027-01-08", terms: 30, advance: 0, budget: 700 }),
  S("S07", "Large urgent order: needs Tier 1 reallocation, CEO decides", "INV NOT ok at agent level · TIER2+TIER1 reallocation · escalate CEO",
    { sku: "FAB-COT-180-A", qty: 45000, cents: 420, deadline: "2026-12-24", terms: 30, advance: 0, budget: 460 }),
  S("S08", "Sea too slow: rush order by air, CEO decides", "INV ok · LOG NOT ok by sea · AIR (100%) · escalate CEO",
    { sku: "FAB-RIB-200-A", qty: 4000, cents: 480, deadline: "2026-12-12", terms: 30, advance: 0, budget: 700 }),
  S("S09", "Price too low: Tommy will not move, rounds run out, escalation", "INV ok · LOG ok · TRE ok · price gap -> ROUNDS_EXPIRED / below agent floor",
    { sku: "FAB-COT-180-A", qty: 20000, cents: 360, deadline: "2027-01-08", terms: 30, advance: 0, budget: 385, concession: 0.25 }),
  S("S10", "Too much, too soon: short of stock and late at every authority, decline", "INV NOT ok (short 7,000) · LOG NOT ok (WIP/production late) · no split, no reallocation · DECLINE (no treasury call)",
    { sku: "FAB-COT-220-A", qty: 45000, cents: 470, deadline: "2027-01-08", terms: 30, advance: 0, budget: 520 }),
];

const mk = (s) => {
  const rfq = structuredClone(base.rfq);
  Object.assign(rfq, { name: `RFQ-${s.id}`, schedule_date: s.deadline, custom_advance_pct: s.advance, custom_payment_terms_days: s.terms });
  Object.assign(rfq.items[0], { item_code: s.sku, item_name: s.sku, description: DESC[s.sku], qty: s.qty, schedule_date: s.deadline, custom_target_rate_cents: s.cents, custom_quality_grade: s.grade ?? "A" });
  return rfq;
};
const usd = (c) => (c == null ? "—" : `$${(c / 100).toFixed(2)}`);
const out = [];
for (const s of SCENARIOS.filter((x) => !f.only || x.id === f.only)) {
  const rfq = mk(s);
  const calls = [];
  const inner = createOutcomeClient({ baseUrl: f["outcome-url"], tenant: "jupiter-knitting", tokenEnv: "QUOTE_TOKEN_JUPITER", lei: policy.seller.lei, timeoutMs: 20000 });
  const client = { ...inner, call: async (alias, path, body) => { const r = await inner.call(alias, path, body); calls.push({ alias, path, request: body, response: r.body }); return r; } };
  const log = [];
  const rec = { scenario: s, rfq: { id: rfq.name, customer: rfq.company, agent: rfq.custom_from_agent, sku: s.sku, grade: s.grade ?? "A", qty: s.qty, targetCents: s.cents, deadline: s.deadline, place: `${rfq.incoterm} ${rfq.named_place}`, termsDays: s.terms, advancePct: s.advance, buyerBudgetCents: s.budget }, calls, log };
  try {
    const sum = await runQuote({
      rfq, policy, client, ai: true, buyer: createRuleBuyer({ budgetCents: s.budget, concession: s.concession ?? 0.5, behaviour: "price" }, s.cents),
      decide: async (req) => { log.push(`ESCALATED to ${req.alias} (${req.level}): ${req.reasons.join(", ")}; counter ${usd(req.counterCents)}, floor ${usd(req.floorCents)} -> ${f.decide}`); return { decision: f.decide, who: req.alias }; },
      onStep: async (ev) => {
        if (ev.type === "plan") log.push(`plan (${ev.level}): ${ev.ok ? "on time" : "NOT on time"} | ${(ev.chunks ?? []).map((c) => `${c.lot}${c.kind === "REALLOC" ? `[${c.tier}]` : ""} ${c.units} ${c.mode} ${c.carrier} ETD ${c.etd} -> ${c.delivered}`).join(" | ")}${(ev.counters ?? []).map((c) => ` | ${c.toBuyer ?? c.internal}`).join("")}`);
        else if (ev.type === "floors") log.push(`floors: ${Object.entries(ev.floors).map(([k, v]) => `${k} ${usd(v)}`).join(", ")}; asks ${ev.asks.map(usd).join("/")}; advance lever ${ev.advance}; importance ${ev.importance.band} (${ev.importance.score})`);
        else if (ev.type === "quote") log.push(`R${ev.round} Jupiter ${ev.decision} ${usd(ev.priceCents)}: "${ev.message}"`);
        else if (ev.type === "buyer") log.push(`R${ev.round} Tommy ${ev.action} ${usd(ev.priceCents)}`);
        else if (ev.type === "escalate") log.push(`escalate: ${ev.reasons.join(", ")} -> ${ev.chain.join(" -> ")}`);
      },
    });
    rec.result = { decision: sum.decision, priceCents: sum.priceCents, totalUsd: sum.priceCents == null ? null : (sum.qty * sum.priceCents) / 100, sku: sum.sku, qty: sum.qty, rounds: sum.rounds, decidedBy: sum.decidedByAlias, reasons: sum.reasons, shipments: sum.shipments, message: sum.message };
  } catch (e) { rec.error = e.message; }
  out.push(rec);
  console.log(`\n=== ${s.id} ${s.title}\n    expect: ${s.expect}`);
  for (const c of calls) console.log(`    · ${c.alias} ${c.path}`);
  for (const l of log) console.log(`    ${l}`);
  console.log(rec.error ? `    FAILED: ${rec.error}` : `    RESULT: ${rec.result.decision} ${usd(rec.result.priceCents)} × ${rec.result.qty} ${rec.result.sku} = $${rec.result.totalUsd?.toLocaleString() ?? "—"} · ${rec.result.decidedBy} · rounds ${rec.result.rounds} · reasons ${rec.result.reasons.join(",") || "—"} · shipments ${JSON.stringify(rec.result.shipments)}`);
}
writeFileSync(f.out, JSON.stringify(out, null, 1));
